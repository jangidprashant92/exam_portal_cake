-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2016 at 03:25 PM
-- Server version: 5.6.26
-- PHP Version: 5.5.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam_portal_cake`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, NULL, NULL, 'controllers', 1, 208),
(2, 1, NULL, NULL, 'Dashboard', 2, 17),
(3, 2, NULL, NULL, 'admin_index', 3, 4),
(4, 2, NULL, NULL, 'upload_image', 5, 6),
(5, 2, NULL, NULL, 'editor_image_upload', 7, 8),
(6, 2, NULL, NULL, 'delete_editor_image', 9, 10),
(7, 2, NULL, NULL, 'addTempMeta', 11, 12),
(8, 2, NULL, NULL, 'updateTempMeta', 13, 14),
(9, 2, NULL, NULL, 'getTempMeta', 15, 16),
(10, 1, NULL, NULL, 'Groups', 18, 39),
(11, 10, NULL, NULL, 'admin_index', 19, 20),
(12, 10, NULL, NULL, 'admin_add', 21, 22),
(13, 10, NULL, NULL, 'admin_edit', 23, 24),
(14, 10, NULL, NULL, 'admin_delete', 25, 26),
(15, 10, NULL, NULL, 'upload_image', 27, 28),
(16, 10, NULL, NULL, 'editor_image_upload', 29, 30),
(17, 10, NULL, NULL, 'delete_editor_image', 31, 32),
(18, 10, NULL, NULL, 'addTempMeta', 33, 34),
(19, 10, NULL, NULL, 'updateTempMeta', 35, 36),
(20, 10, NULL, NULL, 'getTempMeta', 37, 38),
(21, 1, NULL, NULL, 'Home', 40, 55),
(22, 21, NULL, NULL, 'index', 41, 42),
(23, 21, NULL, NULL, 'upload_image', 43, 44),
(24, 21, NULL, NULL, 'editor_image_upload', 45, 46),
(25, 21, NULL, NULL, 'delete_editor_image', 47, 48),
(26, 21, NULL, NULL, 'addTempMeta', 49, 50),
(27, 21, NULL, NULL, 'updateTempMeta', 51, 52),
(28, 21, NULL, NULL, 'getTempMeta', 53, 54),
(29, 1, NULL, NULL, 'Languages', 56, 71),
(30, 29, NULL, NULL, 'admin_set', 57, 58),
(31, 29, NULL, NULL, 'upload_image', 59, 60),
(32, 29, NULL, NULL, 'editor_image_upload', 61, 62),
(33, 29, NULL, NULL, 'delete_editor_image', 63, 64),
(34, 29, NULL, NULL, 'addTempMeta', 65, 66),
(35, 29, NULL, NULL, 'updateTempMeta', 67, 68),
(36, 29, NULL, NULL, 'getTempMeta', 69, 70),
(37, 1, NULL, NULL, 'Permissions', 72, 91),
(38, 37, NULL, NULL, 'admin_index', 73, 74),
(39, 37, NULL, NULL, 'admin_change', 75, 76),
(40, 37, NULL, NULL, 'admin_sync', 77, 78),
(41, 37, NULL, NULL, 'upload_image', 79, 80),
(42, 37, NULL, NULL, 'editor_image_upload', 81, 82),
(43, 37, NULL, NULL, 'delete_editor_image', 83, 84),
(44, 37, NULL, NULL, 'addTempMeta', 85, 86),
(45, 37, NULL, NULL, 'updateTempMeta', 87, 88),
(46, 37, NULL, NULL, 'getTempMeta', 89, 90),
(47, 1, NULL, NULL, 'Questions', 92, 115),
(48, 47, NULL, NULL, 'admin_index', 93, 94),
(49, 47, NULL, NULL, 'admin_view', 95, 96),
(50, 47, NULL, NULL, 'admin_add', 97, 98),
(51, 47, NULL, NULL, 'admin_edit', 99, 100),
(52, 47, NULL, NULL, 'admin_delete', 101, 102),
(53, 47, NULL, NULL, 'upload_image', 103, 104),
(54, 47, NULL, NULL, 'editor_image_upload', 105, 106),
(55, 47, NULL, NULL, 'delete_editor_image', 107, 108),
(56, 47, NULL, NULL, 'addTempMeta', 109, 110),
(57, 47, NULL, NULL, 'updateTempMeta', 111, 112),
(58, 47, NULL, NULL, 'getTempMeta', 113, 114),
(59, 1, NULL, NULL, 'Subjects', 116, 139),
(60, 59, NULL, NULL, 'admin_index', 117, 118),
(61, 59, NULL, NULL, 'admin_view', 119, 120),
(62, 59, NULL, NULL, 'admin_add', 121, 122),
(63, 59, NULL, NULL, 'admin_edit', 123, 124),
(64, 59, NULL, NULL, 'admin_delete', 125, 126),
(65, 59, NULL, NULL, 'upload_image', 127, 128),
(66, 59, NULL, NULL, 'editor_image_upload', 129, 130),
(67, 59, NULL, NULL, 'delete_editor_image', 131, 132),
(68, 59, NULL, NULL, 'addTempMeta', 133, 134),
(69, 59, NULL, NULL, 'updateTempMeta', 135, 136),
(70, 59, NULL, NULL, 'getTempMeta', 137, 138),
(71, 1, NULL, NULL, 'Tests', 140, 171),
(72, 71, NULL, NULL, 'admin_index', 141, 142),
(73, 71, NULL, NULL, 'admin_view', 143, 144),
(74, 71, NULL, NULL, 'admin_add', 145, 146),
(75, 71, NULL, NULL, 'admin_edit', 147, 148),
(76, 71, NULL, NULL, 'admin_delete', 149, 150),
(77, 71, NULL, NULL, 'admin_addSubjectTotest', 151, 152),
(78, 71, NULL, NULL, 'admin_addQuestionsTotest', 153, 154),
(79, 71, NULL, NULL, 'admin_is_publish', 155, 156),
(80, 71, NULL, NULL, 'admin_add_new_row', 157, 158),
(81, 71, NULL, NULL, 'upload_image', 159, 160),
(82, 71, NULL, NULL, 'editor_image_upload', 161, 162),
(83, 71, NULL, NULL, 'delete_editor_image', 163, 164),
(84, 71, NULL, NULL, 'addTempMeta', 165, 166),
(85, 71, NULL, NULL, 'updateTempMeta', 167, 168),
(86, 71, NULL, NULL, 'getTempMeta', 169, 170),
(87, 1, NULL, NULL, 'Users', 172, 205),
(88, 87, NULL, NULL, 'admin_index', 173, 174),
(89, 87, NULL, NULL, 'admin_add', 175, 176),
(90, 87, NULL, NULL, 'admin_edit', 177, 178),
(91, 87, NULL, NULL, 'admin_login', 179, 180),
(92, 87, NULL, NULL, 'admin_logout', 181, 182),
(93, 87, NULL, NULL, 'admin_reset_password', 183, 184),
(94, 87, NULL, NULL, 'admin_delete', 185, 186),
(95, 87, NULL, NULL, 'login', 187, 188),
(96, 87, NULL, NULL, 'register', 189, 190),
(97, 87, NULL, NULL, 'logout', 191, 192),
(98, 87, NULL, NULL, 'upload_image', 193, 194),
(99, 87, NULL, NULL, 'editor_image_upload', 195, 196),
(100, 87, NULL, NULL, 'delete_editor_image', 197, 198),
(101, 87, NULL, NULL, 'addTempMeta', 199, 200),
(102, 87, NULL, NULL, 'updateTempMeta', 201, 202),
(103, 87, NULL, NULL, 'getTempMeta', 203, 204),
(104, 1, NULL, NULL, 'Froala', 206, 207);

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, 'Group', 1, NULL, 1, 2),
(2, NULL, 'Group', 2, NULL, 3, 4),
(3, NULL, 'Group', 3, NULL, 5, 6);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) NOT NULL DEFAULT '0',
  `_read` varchar(2) NOT NULL DEFAULT '0',
  `_update` varchar(2) NOT NULL DEFAULT '0',
  `_delete` varchar(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `alias` varchar(20) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `alias`, `created`, `modified`) VALUES
(1, 'Admin', 'admin', '2016-04-19 15:07:57', '2016-04-19 15:07:57'),
(2, 'Institute', 'Institute', '2016-05-04 15:34:37', '2016-05-04 15:34:37'),
(3, 'public', 'public', '2016-05-04 15:34:47', '2016-05-04 15:34:47');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL,
  `setting` varchar(10) DEFAULT NULL,
  `value` varchar(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting`, `value`) VALUES
(1, 'language', 'eng');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_questions`
--

CREATE TABLE IF NOT EXISTS `tbl_questions` (
  `id` int(10) unsigned NOT NULL,
  `test_id` int(5) unsigned DEFAULT NULL,
  `sub_id` int(11) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `multichoice` int(1) NOT NULL DEFAULT '0',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_question_answers`
--

CREATE TABLE IF NOT EXISTS `tbl_question_answers` (
  `id` int(11) NOT NULL,
  `question_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_question_options`
--

CREATE TABLE IF NOT EXISTS `tbl_question_options` (
  `id` int(10) unsigned NOT NULL,
  `value` varchar(50) NOT NULL,
  `question_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subjects`
--

CREATE TABLE IF NOT EXISTS `tbl_subjects` (
  `id` int(5) unsigned NOT NULL,
  `name` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subjects`
--

INSERT INTO `tbl_subjects` (`id`, `name`) VALUES
(1, 'php'),
(2, 'java'),
(3, 'python'),
(4, 'C#');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_temp`
--

CREATE TABLE IF NOT EXISTS `tbl_temp` (
  `id` int(11) NOT NULL,
  `test_id` int(11) unsigned NOT NULL,
  `meta` varchar(255) NOT NULL,
  `session` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_temp`
--

INSERT INTO `tbl_temp` (`id`, `test_id`, `meta`, `session`) VALUES
(9, 56, 'sub_seq_56', 'a:8:{i:0;s:1:"1";i:1;s:1:"1";i:2;s:1:"1";i:3;s:1:"1";i:4;s:1:"2";i:5;s:1:"2";i:6;s:1:"2";i:7;s:1:"2";}');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test`
--

CREATE TABLE IF NOT EXISTS `tbl_test` (
  `id` int(11) unsigned NOT NULL,
  `user_id` int(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` text NOT NULL,
  `duration` int(20) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `is_publish` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_test`
--

INSERT INTO `tbl_test` (`id`, `user_id`, `name`, `description`, `duration`, `start_date`, `end_date`, `created_at`, `update_at`, `is_publish`, `status`) VALUES
(56, 1, 'test', 'php', 120, '2016-05-12', '2016-05-19', '2016-05-11 10:44:29', '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test_questions`
--

CREATE TABLE IF NOT EXISTS `tbl_test_questions` (
  `id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test_subjects`
--

CREATE TABLE IF NOT EXISTS `tbl_test_subjects` (
  `id` int(11) NOT NULL,
  `test_id` int(11) unsigned NOT NULL,
  `sub_id` int(11) unsigned NOT NULL,
  `no_of_question` int(5) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_test_subjects`
--

INSERT INTO `tbl_test_subjects` (`id`, `test_id`, `sub_id`, `no_of_question`) VALUES
(10, 56, 1, 4),
(11, 56, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_answers`
--

CREATE TABLE IF NOT EXISTS `tbl_user_answers` (
  `id` int(10) unsigned NOT NULL,
  `test_id` int(10) unsigned NOT NULL,
  `user_id` int(10) NOT NULL,
  `question_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_tests`
--

CREATE TABLE IF NOT EXISTS `tbl_user_tests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `test_id` int(11) unsigned DEFAULT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(40) NOT NULL,
  `group_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `group_id`, `created`, `modified`, `status`, `name`, `last_name`, `email`) VALUES
(1, 'admin', '8c83c7253826a1e4143bdc0baec2fd440fe13320', 1, '2016-04-19 15:09:52', '2016-05-01 04:24:42', 1, 'Admin', '', 'admin@admin.com'),
(3, 'pra@gmail.com', '8c83c7253826a1e4143bdc0baec2fd440fe13320', 8, '2016-05-01 05:00:02', '2016-05-04 15:35:43', 1, 'Prashant', 'Jangid', 'pra@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acos`
--
ALTER TABLE `acos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros`
--
ALTER TABLE `aros`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aros_acos`
--
ALTER TABLE `aros_acos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ARO_ACO_KEY` (`aro_id`,`aco_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_test_connct` (`test_id`);

--
-- Indexes for table `tbl_question_answers`
--
ALTER TABLE `tbl_question_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__questions` (`question_id`),
  ADD KEY `FK__questionOptions` (`option_id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indexes for table `tbl_question_options`
--
ALTER TABLE `tbl_question_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Question_connect_Option_FK` (`question_id`);

--
-- Indexes for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_temp`
--
ALTER TABLE `tbl_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKtemp_session_testId` (`test_id`);

--
-- Indexes for table `tbl_test`
--
ALTER TABLE `tbl_test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_test_questions`
--
ALTER TABLE `tbl_test_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_test_subjects`
--
ALTER TABLE `tbl_test_subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_Test_Subjects` (`sub_id`),
  ADD KEY `FK2_Test_id` (`test_id`);

--
-- Indexes for table `tbl_user_answers`
--
ALTER TABLE `tbl_user_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_tbl_user_answers_tbl_test` (`test_id`);

--
-- Indexes for table `tbl_user_tests`
--
ALTER TABLE `tbl_user_tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_tbl_user_tests_user` (`user_id`),
  ADD KEY `FK_tbl_user_tests_tbl_test` (`test_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acos`
--
ALTER TABLE `acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `aros`
--
ALTER TABLE `aros`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `aros_acos`
--
ALTER TABLE `aros_acos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_question_answers`
--
ALTER TABLE `tbl_question_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_question_options`
--
ALTER TABLE `tbl_question_options`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_temp`
--
ALTER TABLE `tbl_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_test`
--
ALTER TABLE `tbl_test`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `tbl_test_questions`
--
ALTER TABLE `tbl_test_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_test_subjects`
--
ALTER TABLE `tbl_test_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_user_answers`
--
ALTER TABLE `tbl_user_answers`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_user_tests`
--
ALTER TABLE `tbl_user_tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_questions`
--
ALTER TABLE `tbl_questions`
  ADD CONSTRAINT `FK_test_connct` FOREIGN KEY (`test_id`) REFERENCES `tbl_test` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tbl_question_answers`
--
ALTER TABLE `tbl_question_answers`
  ADD CONSTRAINT `FK__questionOptions` FOREIGN KEY (`option_id`) REFERENCES `tbl_question_options` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK__questions` FOREIGN KEY (`question_id`) REFERENCES `tbl_questions` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tbl_question_options`
--
ALTER TABLE `tbl_question_options`
  ADD CONSTRAINT `Question_connect_Option_FK` FOREIGN KEY (`question_id`) REFERENCES `tbl_questions` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tbl_temp`
--
ALTER TABLE `tbl_temp`
  ADD CONSTRAINT `FKtemp_session_testId` FOREIGN KEY (`test_id`) REFERENCES `tbl_test` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `tbl_test_subjects`
--
ALTER TABLE `tbl_test_subjects`
  ADD CONSTRAINT `FK2_Test_id` FOREIGN KEY (`test_id`) REFERENCES `tbl_test` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_Test_Subjects` FOREIGN KEY (`sub_id`) REFERENCES `tbl_subjects` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
